﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVCControlsToolkit.Linq
{
    public class TypedConstant
    {
        public object ConstantValue { get; set; }
        public Type ConstantType { get; set; }
    }
}
